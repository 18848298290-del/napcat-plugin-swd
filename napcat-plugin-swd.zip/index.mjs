import fs from 'fs';
import path from 'path';

// ============================================================
// 默认配置
// ============================================================
const DEFAULT_CONFIG = {
  enable: true,
  adminExempt: true,
  enableWarnMessage: true,
  logRetention: 500,
  groupMode: "all",
  groupList: [],
  rules: [
    {
      id: "rule_ad",
      name: "广告检测",
      pattern: "(广告|推广|加微信|加群|扫码|\\d{5,})",
      isRegex: true,
      actions: ["recall", "mute", "warn"],
      muteDuration: 600,
      muteNotify: true,
      muteNotifyMessage: "[CQ:at,qq={user_id}] 因触发违规词「{rule_name}」，已被禁言 {mute_duration} 秒",
      warnMessage: "[CQ:at,qq={user_id}] 检测到「{match_detail}」，触发规则：{rule_name}，消息已撤回",
      enabled: true
    },
    {
      id: "rule_sensitive",
      name: "敏感词示例",
      pattern: "敏感词",
      isRegex: false,
      actions: ["recall", "warn"],
      muteDuration: 300,
      muteNotify: false,
      muteNotifyMessage: "",
      warnMessage: "[CQ:at,qq={user_id}] 检测到违规内容「{match_detail}」，消息已撤回",
      enabled: false
    }
  ]
};

// ============================================================
// 运行时状态
// ============================================================
let logger = null;
let currentConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
let plugin_config_ui = [];
let violationLogs = [];       // 违规日志缓冲区
let stats = {                 // 统计计数器
  totalChecked: 0,
  totalMatched: 0,
  perRule: {}                 // { ruleId: count }
};

// ============================================================
// 工具函数
// ============================================================

/** 生成简短唯一 ID */
function shortId() {
  return 'rule_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6);
}

/** 格式化运行时间 */
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}天 ${hours % 24}小时 ${minutes % 60}分钟`;
  if (hours > 0) return `${hours}小时 ${minutes % 60}分钟`;
  if (minutes > 0) return `${minutes}分钟 ${seconds % 60}秒`;
  return `${seconds}秒`;
}

/** 截断字符串 */
function truncate(str, maxLen = 120) {
  if (!str) return '';
  return str.length > maxLen ? str.slice(0, maxLen) + '...' : str;
}

/** 转义正则特殊字符 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** 模板变量替换 */
function expandVars(template, event, rule, extra = {}) {
  if (!template) return '';
  const vars = {
    '{user_id}': String(event.user_id || ''),
    '{nickname}': event.sender?.nickname || '',
    '{card}': event.sender?.card || '',
    '{rule_name}': rule.name || '',
    '{rule_id}': rule.id || '',
    '{group_name}': event.group_name || '',
    '{group_id}': event.group_id ? String(event.group_id) : '',
    '{match_detail}': extra.matchDetail || '',
    '{mute_duration}': String(rule.muteDuration || 0),
    '{time}': new Date().toLocaleString('zh-CN'),
    ...extra.customVars
  };
  return template.replace(
    /\{user_id\}|\{nickname\}|\{card\}|\{rule_name\}|\{rule_id\}|\{group_name\}|\{group_id\}|\{match_detail\}|\{mute_duration\}|\{time\}/g,
    (match) => vars[match] || match
  );
}

// ============================================================
// 匹配引擎
// ============================================================

/**
 * 对单条规则执行匹配
 * @returns {{ matched: boolean, matchDetail: string }}
 */
function matchRule(rule, rawMessage) {
  if (!rule || !rule.pattern) return { matched: false, matchDetail: '' };

  try {
    if (rule.isRegex) {
      const regex = new RegExp(rule.pattern, 'gi');
      const match = regex.exec(rawMessage);
      if (match) {
        regex.lastIndex = 0; // 重置
        return { matched: true, matchDetail: `正则匹配: "${match[0]}"` };
      }
    } else {
      // 精确匹配，大小写不敏感
      const lowerMsg = rawMessage.toLowerCase();
      const lowerPattern = rule.pattern.toLowerCase();
      if (lowerMsg.includes(lowerPattern)) {
        return { matched: true, matchDetail: `关键词匹配: "${rule.pattern}"` };
      }
    }
  } catch (e) {
    logger?.error(`规则 "${rule.name}" 正则错误:`, e.message);
  }

  return { matched: false, matchDetail: '' };
}

// ============================================================
// 动作执行器
// ============================================================

/**
 * 安全调用 NapCat action，自动处理 "No data returned" 假失败
 * delete_msg / set_group_ban / set_group_kick 成功后返回 null，
 * 但 NapCat 框架会误判为失败。此函数将其视为成功。
 */
async function safeCallAction(ctx, actionName, params) {
  try {
    await ctx.actions.call(actionName, params, ctx.adapterName, ctx.pluginManager.config);
  } catch (e) {
    if (!e.message || !e.message.includes('No data returned')) {
      throw e; // 真正的错误才往上抛
    }
  }
}

/**
 * 执行单条规则定义的所有动作
 * 每个动作独立 try-catch，一个失败不影响后续
 */
async function executeActions(ctx, event, rule, matchDetail) {
  const results = [];
  const { actions: actionList = [] } = rule;
  const groupId = String(event.group_id);
  const userId = String(event.user_id);
  const messageId = event.message_id;

  for (const action of actionList) {
    try {
      switch (action) {
        case 'recall': {
          await safeCallAction(ctx, 'delete_msg', { message_id: messageId });
          results.push('recall:ok');
          logger?.info(`[${rule.name}] 已撤回消息 ${messageId}`);
          break;
        }

        case 'mute': {
          const duration = rule.muteDuration || 600;
          await safeCallAction(ctx, 'set_group_ban', {
            group_id: groupId,
            user_id: userId,
            duration: String(duration)
          });
          results.push(`mute:${duration}s`);
          logger?.info(`[${rule.name}] 已禁言 ${userId} ${duration}秒`);

          // 禁言后发送 @ 提醒
          if (rule.muteNotify && rule.muteNotifyMessage) {
            try {
              const notifyMsg = expandVars(rule.muteNotifyMessage, event, rule, { matchDetail });
              await ctx.actions.call('send_msg', {
                message_type: event.message_type,
                group_id: groupId,
                message: notifyMsg
              }, ctx.adapterName, ctx.pluginManager.config);
              results.push('mute-notify:ok');
              logger?.info(`[${rule.name}] 禁言通知已发送`);
            } catch (ne) {
              logger?.error(`[${rule.name}] 禁言通知发送失败:`, ne.message);
              results.push(`mute-notify:error(${ne.message})`);
            }
          }
          break;
        }

        case 'kick': {
          await safeCallAction(ctx, 'set_group_kick', {
            group_id: groupId,
            user_id: userId,
            reject_add_request: false
          });
          results.push('kick:ok');
          logger?.info(`[${rule.name}] 已踢出 ${userId}`);
          break;
        }

        case 'warn': {
          if (currentConfig.enableWarnMessage && rule.warnMessage) {
            const message = expandVars(rule.warnMessage, event, rule, { matchDetail });
            await ctx.actions.call('send_msg', {
              message_type: event.message_type,
              group_id: groupId,
              message: message
            }, ctx.adapterName, ctx.pluginManager.config);
            results.push('warn:ok');
          } else {
            results.push('warn:skipped');
          }
          break;
        }

        default:
          logger?.warn(`[${rule.name}] 未知动作: ${action}`);
          results.push(`${action}:unknown`);
      }
    } catch (e) {
      logger?.error(`[${rule.name}] 动作 ${action} 执行失败:`, e.message);
      results.push(`${action}:error(${e.message})`);
    }
  }

  return results;
}

// ============================================================
// 日志缓冲
// ============================================================

function addViolationLog(entry) {
  violationLogs.unshift(entry);
  const maxLogs = currentConfig.logRetention || 500;
  if (violationLogs.length > maxLogs) {
    violationLogs = violationLogs.slice(0, maxLogs);
  }
}

// ============================================================
// 插件生命周期
// ============================================================

const startTime = Date.now();

const plugin_init = async (ctx) => {
  logger = ctx.logger;
  logger.info('========================================');
  logger.info('  SWD 违规词检测插件 v0.1.0 已加载');
  logger.info('========================================');

  // --- 加载持久化配置 ---
  try {
    if (fs.existsSync(ctx.configPath)) {
      const saved = JSON.parse(fs.readFileSync(ctx.configPath, 'utf-8'));
      // 深度合并：保留默认 rules 结构，用保存的值覆盖
      currentConfig = deepMerge(DEFAULT_CONFIG, saved);
      logger.info('已加载持久化配置');
    }
  } catch (e) {
    logger.warn('加载配置失败，使用默认配置', e.message);
  }

  // --- 初始化统计 ---
  resetPerRuleStats();

  // --- 构建 Config UI ---
  plugin_config_ui = ctx.NapCatConfig.combine(
    ctx.NapCatConfig.html(
      '<div style="padding:12px;background:rgba(0,0,0,0.05);border-radius:8px;margin-bottom:8px;">' +
      '<h3 style="margin:0 0 6px;">🛡️ SWD 违规词检测</h3>' +
      '<p style="margin:0;font-size:13px;color:#666;">自动检测违规消息，支持撤回、禁言、踢出、警告等多种处理方式。<br>规则管理请使用 <b>规则管理</b> 页面（左侧菜单）。</p>' +
      '</div>'
    ),
    ctx.NapCatConfig.boolean("enable", "启用审核", true, "总开关，关闭后所有消息不做检查"),
    ctx.NapCatConfig.select("groupMode", "群聊范围", [
      { label: "全部群聊", value: "all" },
      { label: "白名单模式 (仅指定群)", value: "whitelist" },
      { label: "黑名单模式 (排除指定群)", value: "blacklist" }
    ], "all", "选择审核插件生效的群聊范围。群号列表在规则管理页面配置"),
    ctx.NapCatConfig.boolean("adminExempt", "豁免管理员", true, "群主和管理员的消息不检查"),
    ctx.NapCatConfig.boolean("enableWarnMessage", "发送警告消息", true, "违规时是否在群里发送警告"),
    ctx.NapCatConfig.number("logRetention", "日志保留条数", 500, "内存中最多保留多少条违规日志")
  );

  // --- 注册路由 ---
  registerRoutes(ctx);

  logger.info('路由已注册:');
  logger.info(`  状态:  /api/Plugin/ext/${ctx.pluginName}/status`);
  logger.info(`  日志:  /api/Plugin/ext/${ctx.pluginName}/logs`);
  logger.info(`  测试:  /api/Plugin/ext/${ctx.pluginName}/test`);
  logger.info(`  仪表盘: /plugin/${ctx.pluginName}/page/dashboard`);
  logger.info(`  规则管理: /plugin/${ctx.pluginName}/page/rules`);
};

const plugin_cleanup = async (_ctx) => {
  logger?.info('SWD 违规词检测插件已卸载');
  logger?.info(`  运行期间共检查 ${stats.totalChecked} 条消息，命中 ${stats.totalMatched} 条`);
};

const plugin_get_config = async () => {
  return currentConfig;
};

const plugin_set_config = async (ctx, config) => {
  currentConfig = config;
  if (ctx && ctx.configPath) {
    try {
      const dir = path.dirname(ctx.configPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(ctx.configPath, JSON.stringify(config, null, 2), 'utf-8');
      resetPerRuleStats();
    } catch (e) {
      logger?.error('保存配置失败', e.message);
      throw e;
    }
  }
};

const plugin_config_controller = async (_ctx, ui, initialConfig) => {
  logger?.info('配置控制器已初始化');
  // 返回清理函数
  return () => {
    logger?.info('配置控制器已清理');
  };
};

const plugin_on_config_change = async (_ctx, ui, key, value, _currentConfig) => {
  logger?.info(`配置变更: ${key} = ${JSON.stringify(value)}`);
};

// ============================================================
// 消息处理 (核心)
// ============================================================

const plugin_onmessage = async (ctx, event) => {
  // 1. 总开关检查
  if (!currentConfig.enable) return;

  // 2. 只处理消息事件（排除 message_sent 等）
  if (event.post_type !== 'message') return;

  // 3. 只处理群消息
  if (event.message_type !== 'group') return;

  // 4. 豁免管理员
  if (currentConfig.adminExempt) {
    const role = event.sender?.role;
    if (role === 'owner' || role === 'admin') {
      return;
    }
  }

  // 5. 群聊开关检查
  const groupMode = currentConfig.groupMode || 'all';
  if (groupMode !== 'all') {
    const groupId = String(event.group_id);
    const list = Array.isArray(currentConfig.groupList) ? currentConfig.groupList : [];
    const inList = list.map(String).includes(groupId);
    if (groupMode === 'whitelist' && !inList) return;
    if (groupMode === 'blacklist' && inList) return;
  }

  stats.totalChecked++;

  const rawMessage = event.raw_message || '';
  if (!rawMessage) return;

  const rules = currentConfig.rules || [];

  // 6. 遍历规则匹配
  for (const rule of rules) {
    if (!rule.enabled) continue;
    if (!rule.pattern) continue;

    const { matched, matchDetail } = matchRule(rule, rawMessage);
    if (!matched) continue;

    // 命中！
    stats.totalMatched++;
    stats.perRule[rule.id] = (stats.perRule[rule.id] || 0) + 1;

    logger?.info(
      `[${rule.name}] 命中 | ` +
      `群:${event.group_id} 用户:${event.sender?.nickname || event.user_id} | ` +
      matchDetail
    );

    // 6. 执行动作
    const actionResults = await executeActions(ctx, event, rule, matchDetail);

    // 7. 记录日志
    addViolationLog({
      time: new Date().toISOString(),
      timestamp: Date.now(),
      group_id: event.group_id,
      group_name: event.group_name || '',
      user_id: event.user_id,
      nickname: event.sender?.nickname || '',
      card: event.sender?.card || '',
      rule_id: rule.id,
      rule_name: rule.name,
      matched_content: truncate(rawMessage),
      match_detail: matchDetail,
      actions_taken: actionResults
    });
  }
};

// ============================================================
// 路由注册
// ============================================================

function registerRoutes(ctx) {
  // --- 插件状态 ---
  ctx.router.get('/status', (_req, res) => {
    const uptime = Date.now() - startTime;
    res.json({
      code: 0,
      data: {
        pluginName: ctx.pluginName,
        uptime,
        uptimeFormatted: formatUptime(uptime),
        platform: process.platform,
        enable: currentConfig.enable,
        adminExempt: currentConfig.adminExempt,
        groupMode: currentConfig.groupMode || 'all',
        groupList: currentConfig.groupList || [],
        ruleCount: (currentConfig.rules || []).length,
        enabledRuleCount: (currentConfig.rules || []).filter(r => r.enabled).length,
        stats: {
          totalChecked: stats.totalChecked,
          totalMatched: stats.totalMatched,
          perRule: stats.perRule
        },
        logCount: violationLogs.length
      }
    });
  });

  // --- 配置读写 ---
  ctx.router.get('/config', (_req, res) => {
    res.json({ code: 0, data: currentConfig });
  });

  ctx.router.post('/config', (req, res) => {
    try {
      const newConfig = req.body;
      currentConfig = deepMerge(currentConfig, newConfig);
      const dir = path.dirname(ctx.configPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2), 'utf-8');
      resetPerRuleStats();
      res.json({ code: 0, message: '配置已保存' });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- 规则 CRUD ---
  ctx.router.get('/rules', (_req, res) => {
    res.json({ code: 0, data: currentConfig.rules || [] });
  });

  ctx.router.post('/rules', (req, res) => {
    try {
      const rule = req.body;
      if (!rule.name || !rule.pattern) {
        res.status(400).json({ code: -1, message: '规则名称和匹配模式为必填项' });
        return;
      }
      rule.id = rule.id || shortId();
      rule.actions = rule.actions || ['recall'];
      rule.muteDuration = rule.muteDuration || 600;
      rule.muteNotify = rule.muteNotify !== undefined ? rule.muteNotify : true;
      rule.muteNotifyMessage = rule.muteNotifyMessage || '[CQ:at,qq={user_id}] 因触发违规词「{rule_name}」，已被禁言 {mute_duration} 秒';
      rule.warnMessage = rule.warnMessage || '[CQ:at,qq={user_id}] 检测到违规内容「{match_detail}」，触发规则：{rule_name}';
      rule.enabled = rule.enabled !== undefined ? rule.enabled : true;
      rule.isRegex = rule.isRegex !== undefined ? rule.isRegex : false;

      if (!currentConfig.rules) currentConfig.rules = [];
      currentConfig.rules.push(rule);
      saveConfigToDisk(ctx);
      resetPerRuleStats();
      res.json({ code: 0, data: rule, message: '规则已添加' });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  ctx.router.post('/rules/update', (req, res) => {
    try {
      const { ruleId, ...updates } = req.body;
      if (!ruleId) { res.status(400).json({ code: -1, message: '缺少 ruleId' }); return; }
      const idx = (currentConfig.rules || []).findIndex(r => r.id === ruleId);
      if (idx === -1) {
        res.status(404).json({ code: -1, message: '规则未找到' });
        return;
      }
      delete updates.id;
      Object.assign(currentConfig.rules[idx], updates);
      saveConfigToDisk(ctx);
      resetPerRuleStats();
      res.json({ code: 0, data: currentConfig.rules[idx], message: '规则已更新' });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  ctx.router.post('/rules/delete', (req, res) => {
    try {
      const { ruleId } = req.body;
      if (!ruleId) { res.status(400).json({ code: -1, message: '缺少 ruleId' }); return; }
      const idx = (currentConfig.rules || []).findIndex(r => r.id === ruleId);
      if (idx === -1) {
        res.status(404).json({ code: -1, message: '规则未找到' });
        return;
      }
      const removed = currentConfig.rules.splice(idx, 1)[0];
      saveConfigToDisk(ctx);
      resetPerRuleStats();
      res.json({ code: 0, data: removed, message: '规则已删除' });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- 批量启用/禁用规则 ---
  ctx.router.post('/rules/toggle', (req, res) => {
    try {
      const { ruleId } = req.body;
      if (!ruleId) { res.status(400).json({ code: -1, message: '缺少 ruleId' }); return; }
      const rule = (currentConfig.rules || []).find(r => r.id === ruleId);
      if (!rule) {
        res.status(404).json({ code: -1, message: '规则未找到' });
        return;
      }
      rule.enabled = !rule.enabled;
      saveConfigToDisk(ctx);
      res.json({ code: 0, data: rule, message: `规则已${rule.enabled ? '启用' : '禁用'}` });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- 违规日志 ---
  ctx.router.get('/logs', (req, res) => {
    const limit = Math.min(parseInt(req.query?.limit) || 50, 500);
    const offset = parseInt(req.query?.offset) || 0;
    res.json({
      code: 0,
      data: {
        total: violationLogs.length,
        logs: violationLogs.slice(offset, offset + limit)
      }
    });
  });

  ctx.router.post('/logs/clear', (_req, res) => {
    violationLogs = [];
    res.json({ code: 0, message: '日志已清空' });
  });

  // --- 文本测试（不执行动作） ---
  ctx.router.post('/test', (req, res) => {
    try {
      const { text, rules: testRules } = req.body;
      if (!text) {
        res.status(400).json({ code: -1, message: '请提供测试文本' });
        return;
      }
      const rulesToTest = testRules || currentConfig.rules || [];
      const results = [];

      for (const rule of rulesToTest) {
        if (!rule.enabled) continue;
        const { matched, matchDetail } = matchRule(rule, text);
        if (matched) {
          results.push({
            rule_id: rule.id,
            rule_name: rule.name,
            pattern: rule.pattern,
            isRegex: rule.isRegex,
            matched: true,
            match_detail: matchDetail,
            would_actions: rule.actions
          });
        }
      }

      res.json({
        code: 0,
        data: {
          text: truncate(text, 200),
          tested_rules: rulesToTest.filter(r => r.enabled).length,
          matched_count: results.length,
          results
        }
      });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- TXT 词库导入 ---
  ctx.router.post('/import-words', (req, res) => {
    try {
      const { words, ruleName, mode, defaultActions, muteDuration, enabled } = req.body;
      if (!words || typeof words !== 'string' || !words.trim()) {
        res.status(400).json({ code: -1, message: '请提供词库内容 (words 字段)' });
        return;
      }
      if (!ruleName || !ruleName.trim()) {
        res.status(400).json({ code: -1, message: '请提供规则名称' });
        return;
      }
      if (!mode || !['combined', 'single'].includes(mode)) {
        res.status(400).json({ code: -1, message: 'mode 必须是 combined 或 single' });
        return;
      }

      // 解析词库：每行一个词，忽略空行和注释行(#开头)
      const lines = words.split(/\r?\n/)
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('#'));

      if (lines.length === 0) {
        res.status(400).json({ code: -1, message: '词库中没有有效词汇' });
        return;
      }

      const actions = (defaultActions && defaultActions.length > 0) ? defaultActions : ['recall'];
      const duration = muteDuration || 600;
      const isEnabled = enabled !== false;
      const muteNotify = req.body.muteNotify !== undefined ? req.body.muteNotify : (actions.includes('mute'));
      const muteNotifyMsg = req.body.muteNotifyMessage || '[CQ:at,qq={user_id}] 因触发违规词「{rule_name}」，已被禁言 {mute_duration} 秒';
      const createdRules = [];

      if (mode === 'combined') {
        // 合并为一条正则规则，特殊字符转义
        const escaped = lines.map(escapeRegex);
        const pattern = '(' + escaped.join('|') + ')';
        const rule = {
          id: shortId(),
          name: ruleName.trim(),
          pattern: pattern,
          isRegex: true,
          actions: actions,
          muteDuration: duration,
          muteNotify: muteNotify,
          muteNotifyMessage: muteNotifyMsg,
          warnMessage: '',
          enabled: isEnabled
        };
        if (!currentConfig.rules) currentConfig.rules = [];
        currentConfig.rules.push(rule);
        createdRules.push(rule);
      } else {
        // 每个词一条精确匹配规则
        for (const word of lines) {
          const rule = {
            id: shortId(),
            name: `${ruleName.trim()} - ${truncate(word, 30)}`,
            pattern: word,
            isRegex: false,
            actions: actions,
            muteDuration: duration,
            muteNotify: muteNotify,
            muteNotifyMessage: muteNotifyMsg,
            warnMessage: '',
            enabled: isEnabled
          };
          if (!currentConfig.rules) currentConfig.rules = [];
          currentConfig.rules.push(rule);
          createdRules.push(rule);
        }
      }

      saveConfigToDisk(ctx);
      resetPerRuleStats();
      logger?.info(`词库导入完成: ${createdRules.length} 条规则 (模式: ${mode})`);

      res.json({
        code: 0,
        data: { imported: createdRules.length, mode, rules: createdRules },
        message: `成功导入 ${createdRules.length} 条规则`
      });
    } catch (e) {
      logger?.error('导入词库失败:', e.message);
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- 群聊配置 ---
  ctx.router.get('/groups', (_req, res) => {
    res.json({
      code: 0,
      data: {
        groupMode: currentConfig.groupMode || 'all',
        groupList: currentConfig.groupList || []
      }
    });
  });

  ctx.router.post('/groups', (req, res) => {
    try {
      const { groupMode, groupList } = req.body;
      if (groupMode && !['all', 'whitelist', 'blacklist'].includes(groupMode)) {
        res.status(400).json({ code: -1, message: 'groupMode 无效' });
        return;
      }
      if (groupList !== undefined && !Array.isArray(groupList)) {
        res.status(400).json({ code: -1, message: 'groupList 必须是数组' });
        return;
      }
      if (groupMode) currentConfig.groupMode = groupMode;
      if (groupList !== undefined) currentConfig.groupList = groupList.map(String);
      saveConfigToDisk(ctx);
      res.json({
        code: 0,
        data: { groupMode: currentConfig.groupMode, groupList: currentConfig.groupList },
        message: '群聊配置已保存'
      });
    } catch (e) {
      res.status(500).json({ code: -1, message: e.message });
    }
  });

  // --- WebUI 页面 ---
  ctx.router.pages([
    {
      path: 'dashboard',
      title: '审核仪表盘',
      icon: '🛡️',
      htmlFile: 'webui/dashboard.html',
      description: '查看审核插件运行状态、统计和违规日志'
    },
    {
      path: 'rules',
      title: '规则管理',
      icon: '📋',
      htmlFile: 'webui/rules-manager.html',
      description: '管理违规词检测规则'
    }
  ]);

  // 静态资源
  ctx.router.static('/static', 'webui');
}

// ============================================================
// 辅助函数
// ============================================================

/** 深度合并配置（保留未提供的 key，跳过 null/undefined） */
function deepMerge(base, override) {
  if (!override || typeof override !== 'object') return base;
  const result = JSON.parse(JSON.stringify(base));
  for (const key of Object.keys(override)) {
    const val = override[key];
    if (val === null || val === undefined) continue; // 跳过空值，不覆盖
    if (key === 'rules' && Array.isArray(val)) {
      result.rules = JSON.parse(JSON.stringify(val));
    } else if (
      typeof val === 'object' &&
      !Array.isArray(val) &&
      typeof result[key] === 'object' &&
      !Array.isArray(result[key])
    ) {
      result[key] = deepMerge(result[key], val);
    } else {
      result[key] = JSON.parse(JSON.stringify(val));
    }
  }
  return result;
}

/** 保存配置到磁盘 */
function saveConfigToDisk(ctx) {
  try {
    const dir = path.dirname(ctx.configPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2), 'utf-8');
  } catch (e) {
    logger?.error('保存配置失败', e.message);
  }
}

/** 重置每规则统计 */
function resetPerRuleStats() {
  stats.perRule = {};
  for (const rule of (currentConfig.rules || [])) {
    stats.perRule[rule.id] = 0;
  }
}

// ============================================================
// 导出
// ============================================================

export {
  plugin_init,
  plugin_cleanup,
  plugin_onmessage,
  plugin_get_config,
  plugin_set_config,
  plugin_config_ui,
  plugin_config_controller,
  plugin_on_config_change
};
